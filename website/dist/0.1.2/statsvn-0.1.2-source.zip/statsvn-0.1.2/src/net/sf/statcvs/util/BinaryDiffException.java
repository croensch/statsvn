package net.sf.statcvs.util;

public class BinaryDiffException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1897989743777577565L;

}
